# Cyclistic Case Study: R Analysis Script

# Load libraries
library(data.table)
library(ggplot2)
library(dplyr)

# Load cleaned dataset (adjust path)
trips <- fread("data/cleaned/Cleaned_bicycledata.csv")

# Basic summary
print(dim(trips))
print(head(trips))

# Average ride length by user type
avg_ride <- trips %>% 
  group_by(member_casual) %>% 
  summarise(avg_length = mean(ride_length_minutes, na.rm=TRUE))
print(avg_ride)

# Ride length distribution plot
p1 <- ggplot(trips, aes(x = member_casual, y = ride_length_minutes, fill = member_casual)) +
  geom_boxplot() +
  coord_cartesian(ylim = c(0, 60)) +
  labs(title="Ride Length Distribution", x="User Type", y="Ride Length (mins)") +
  theme_minimal()
ggsave("outputs/figures/ride_length_distribution.png", p1)

# Rides by day of week
p2 <- trips %>% 
  group_by(day_of_week, member_casual) %>% 
  summarise(rides = n(), .groups="drop") %>% 
  ggplot(aes(x = day_of_week, y = rides, fill = member_casual)) +
  geom_col(position="dodge") +
  labs(title="Rides by Day of Week") +
  theme_minimal()
ggsave("outputs/figures/rides_by_day.png", p2)

# Save summary report
sink("outputs/reports/summary.txt")
cat("Cyclistic Bike-Share Case Study Report\n")
cat("----------------------------------\n\n")
print(avg_ride)
sink()
