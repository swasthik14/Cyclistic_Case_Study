# Cyclistic Bike-Share Case Study 🚲

## 📌 About
This project is the Google Data Analytics Capstone case study using Cyclistic's bike-share data.  
The goal is to analyze how casual riders and annual members use Cyclistic bikes differently.

## 🗂️ Project Structure
```
Cyclistic_Case_Study/
│── data/
│   ├── raw/        <- raw monthly CSVs (from Divvy portal)
│   ├── cleaned/    <- cleaned dataset (NOT uploaded, too large)
│── scripts/
│   ├── sql/        <- SQL scripts for cleaning & processing
│   ├── r/          <- R scripts for analysis & visualization
│── outputs/
│   ├── figures/    <- charts & plots
│   ├── reports/    <- final report (RMarkdown/HTML/PDF)
│── README.md
│── .gitignore
```

⚠️ **Note**: The cleaned dataset (~2GB) is NOT uploaded here due to GitHub limits.  
Download raw Divvy trip data from: https://divvy-tripdata.s3.amazonaws.com/index.html  
Then clean using the provided SQL scripts.

## 🚀 Steps
1. Load raw data → SQL → Clean → Export CSV.
2. Import cleaned CSV into R.
3. Run analysis & visualization scripts.
4. Generate insights & final report.

